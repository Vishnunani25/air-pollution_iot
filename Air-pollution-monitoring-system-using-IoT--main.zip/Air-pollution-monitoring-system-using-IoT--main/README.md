# Air-pollution-monitoring-system-using-IoT
Project Summary: Combatting urban air pollution, this IoT-based system monitors air quality in real-time using sensors like MQ135 and MQ6. The LCD displays PPM values, and the system triggers alarms when air quality deteriorates, saving logs for future analysis and intervention.
![Screenshot 2024-03-02 123529](https://github.com/saivarshith18/Air-pollution-monitoring-system-using-IoT/assets/139994815/16ae0f9b-ca99-499e-93ed-3a5f3da81cd4)
![Screenshot 2024-03-02 124636](https://github.com/saivarshith18/Air-pollution-monitoring-system-using-IoT/assets/139994815/cc20e8c6-e6ec-49e1-b07e-1dc09f3e6cc6)
![Screenshot 2024-03-02 123625](https://github.com/saivarshith18/Air-pollution-monitoring-system-using-IoT/assets/139994815/6fdd79cd-fdcc-47e6-9919-4ede9c308511)
